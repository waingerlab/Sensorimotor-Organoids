%% Parser for plate
%function

function [wellnames,wellarray] = Muscle_contraction_parser(folder);

files = glob(strcat(folder,'*'));
foldernamelength = numel(folder)+1;

test = cellfun(@(x) x(foldernamelength:foldernamelength+2),files,'UniformOutput',false); %function that pulls well names
test = cell2mat(test);
wells = unique(test,'rows');
wellnames = cell(numel(wells(:,1)),1);

wellarray = cell(numel(wells(:,1)),1);

for n = 1:numel(wells(:,1))
    wellarray{n} = glob(strcat(folder,'/',wells(n,:),'*.tif'));
    wellnames{n} = strcat(folder,wells(n,:));
end
