%% Muscle contraction batch v2

addpath('G:/Scripts/Universal_functions','G:/Scripts/Muscle_contraction');

folders = glob('*/');

%this next line could be changed so that multiple plates can be analyzed
%folderoffolders = cell(numel(folders),1);

[filenames,wellarray] = Muscle_contraction_parser(folders{1});

datamatrix = zeros(numel(wellarray),numel(wellarray{1}));

for n = 1:numel(wellarray)
    datamatrix(n,:) = Muscle_contraction_v4(wellarray{n});
    filenames{n} = strrep(filenames{n},'\','_'); %may need to be optimized
end


xlswrite('Contraction_analysis_AH.xlsx',datamatrix,'Summary','b1') %writes data out
xlswrite('Contraction_analysis_AH.xlsx',filenames,'Summary','a1') %writes filenames out

Muscle_contraction_peakanalysis_v3