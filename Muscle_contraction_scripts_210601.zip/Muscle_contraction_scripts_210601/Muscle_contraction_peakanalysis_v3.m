%% This script takes excel file data and plots it

xlsfile = 'Contraction_analysis_AH.xlsx'
sheet = 'Summary';

mkdir 'AH_plots';

data = xlsread(xlsfile,sheet,'c1:dkl144');
[num, names, raw] = xlsread(xlsfile,sheet,'a1:a144');

%peak detector
for n = 1:144
    trace = data(n,:);
    start = 1; 
    stop = 25;
    finish = 3001;
    peaks = [];
    amplitudes = [];
    while start<2976
        ROI = trace(start:stop);
        med = median(ROI);
        [val, ind] = max(ROI);
        if val>med+10
            peaks = [peaks,ind+start-1];
            amplitudes = [amplitudes, trace(ind+start-1)-med];
            start = start+ind+25;
            stop = stop+ind+25;
        else
            start = start+25;
            stop = stop+25;
        end
    end
    f = figure('visible','off');
    plot(trace)
    hold on
    scatter(peaks,trace(peaks))
    title(names{n}(1:end-1));
    saveas(f,strcat('AH_plots/',names{n}(1:end),'.tif'))
    if numel(peaks)>0
        xlswrite(xlsfile,peaks,'PeakTime_lowercutoff',strcat('b',int2str(n)));
        xlswrite(xlsfile,amplitudes,'PeakAmplitude_lowercutoff',strcat('b',int2str(n)));
    end
end

xlswrite(xlsfile,names,'PeakTime_lowercutoff','a1');
xlswrite(xlsfile,names,'PeakAmplitude_lowercutoff','a1');