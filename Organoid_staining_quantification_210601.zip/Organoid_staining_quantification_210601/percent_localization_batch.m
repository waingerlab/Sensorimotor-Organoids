%% This is a batch script that calls percent_localization. It assumes the image is RGB format and that B is the nuclear channel
addpath('H:/Scripts/Universal_functions')

files = glob('H:/Joao/*/Stitched_Images/*');

totaltemp = cell(numel(files),1);
doubletemp = cell(numel(files),1);
redtemp = cell(numel(files),1);
greentemp = cell(numel(files),1);
negtemp = cell(numel(files),1);


parfor n = 1:numel(files)
    [totalcounts,percentdouble,percentred,percentgreen,percentnegative] = percent_localization(tifread(files{n}));
    totaltemp{n} = totalcounts;
    doubletemp{n} = percentdouble;
    redtemp{n} = percentred;
    greentemp{n} = percentgreen;
    negtemp{n} = percentnegative;
end

total = unevencat(totaltemp);
double = unevencat(doubletemp);
red = unevencat(redtemp);
green = unevencat(greentemp);
neg = unevencat(negtemp);


objectcounts = cellfun(@numel,totaltemp);
doublesummary = cellfun(@mean,doubletemp);
redsummary = cellfun(@mean,redtemp);
greensummary = cellfun(@mean,greentemp);
negsummary = cellfun(@mean,negtemp);

xlswrite('organoid_localization.xlsx',files,'Summary','A2');
xlswrite('organoid_localization.xlsx',{'filenames','organoidnumber','percent_dualpositive','percent_redonly','percent_greenonly','percent_negative'},'Summary','A1');
xlswrite('organoid_localization.xlsx',[objectcounts,doublesummary,redsummary,greensummary,negsummary],'Summary','B2');

xlswrite('organoid_localization.xlsx',files,'Area','A2');
xlswrite('organoid_localization.xlsx',total,'Area','B2');

xlswrite('organoid_localization.xlsx',files,'doublepositive','A2');
xlswrite('organoid_localization.xlsx',double,'doublepositive','B2');

xlswrite('organoid_localization.xlsx',files,'redonly','A2');
xlswrite('organoid_localization.xlsx',red,'redonly','B2');

xlswrite('organoid_localization.xlsx',files,'greenonly','A2');
xlswrite('organoid_localization.xlsx',green,'greenonly','B2');

xlswrite('organoid_localization.xlsx',files,'negative','A2');
xlswrite('organoid_localization.xlsx',neg,'negative','B2');
