%% This function finds organoid objects and then determines percent positive for each channel
% several functions in the "universal functions" folder are required 
function [totalcounts,percentdouble,percentred,percentgreen,percentnegative] = percent_localization(image);


%a blur is needed to label groups of cells as opposed to individuals
blurredimage = imgaussfilt(image(:,:,3),10);

%binarize
nucleibinarymask = imbinarize(blurredimage);

%filter by size
filteredmask = bwareafilt(nucleibinarymask,[20000 10000000]); %this is an arbitrary cutoff based on what I think is an appropriately sized object

%identify objects
[borders,nucleiobjectmask] = bwboundaries(filteredmask,'noholes');

%imshow(label2rgb(nucleiobjectmask,'jet','k','shuffle')) %image image of organoid mask

% restrict mask to nuclei
revisednucleiobjectmask = immultiply(nucleiobjectmask,imbinarize(image(:,:,3)));

%imshow(label2rgb(revisednucleiobjectmask,'jet','k','shuffle')) %this shows
%the labeled image

% make masks of other two channels - use bradley function
redmask = bradley(image(:,:,1),[500 500],.000001);
greenmask = bradley(image(:,:,2),[500 500],.000001);

%determine how much of each object is covered by red and green masks
redmask2 = immultiply(redmask,logical(revisednucleiobjectmask));
greenmask2 = immultiply(greenmask,logical(revisednucleiobjectmask));
doublepositive = immultiply(redmask2,greenmask2);
redmask3 = redmask2-doublepositive;
greenmask3 = greenmask2-doublepositive;
negativemask = logical(revisednucleiobjectmask)-redmask3-greenmask3-doublepositive;

objectnumber = max(revisednucleiobjectmask,[],'all');

doubleposcounts = countmember([1:objectnumber],immultiply(doublepositive,revisednucleiobjectmask));
redonlycounts = countmember([1:objectnumber],immultiply(redmask3,revisednucleiobjectmask));
greenonlycounts = countmember([1:objectnumber],immultiply(greenmask3,revisednucleiobjectmask));
negativecounts = countmember([1:objectnumber],immultiply(negativemask,revisednucleiobjectmask));
totalcounts = doubleposcounts+redonlycounts+greenonlycounts+negativecounts;

percentdouble = 100*doubleposcounts./totalcounts;
percentred = 100*redonlycounts./totalcounts;
percentgreen = 100*greenonlycounts./totalcounts;
percentnegative = 100*negativecounts./totalcounts;